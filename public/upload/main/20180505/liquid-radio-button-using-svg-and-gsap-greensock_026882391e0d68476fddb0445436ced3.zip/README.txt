A Pen created at CodePen.io. You can find this one at https://codepen.io/ryan_labar/pen/PjYMvW.

 Based on this design: https://dribbble.com/shots/1933701-Liquid-Radio-Button
